fx_version 'cerulean'
games { 'rdr3', 'gta5' }

author 'hitman <https://discord.gg/TnfrHg7CPV>'
description 'Pablo Taco By hitman'
version '1.0.0'

files {
	'peds.meta'
}


data_file 'PED_METADATA_FILE' 'peds.meta'
dependency '/assetpacks'